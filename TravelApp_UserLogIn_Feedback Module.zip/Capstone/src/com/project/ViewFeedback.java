package com.project;



import java.time.Duration;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeDriverService;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class ViewFeedback {

	private static WebDriver driver;
	 
	@BeforeAll	
	static void setup()//main(String[] args) throws InterruptedException
	
	{
		
		System.setProperty("webdriver.chrome.driver","C:\\SeleniumInfo\\chrome_drivers\\chromedriver.exe");
		
	    driver = new ChromeDriver();
	    
		driver.get("http://localhost:8080/TravelApp/");
	    
		
	    System.setProperty(ChromeDriverService.CHROME_DRIVER_SILENT_OUTPUT_PROPERTY, "true"); 
	    
	}
	
	@Test
	@Order(1)
	 
	   void viewfeedback() throws InterruptedException
	   {
		   //driver.get("http://localhost:8080/TravelApp/User.html");
		   
		   driver.get("http://localhost:8080/TravelApp/");
		   
		   WebElement userlogin = driver.findElement(By.className("loginButton")); //Targetting the searchbox element normal user login
		   userlogin.click();
		  
		   WebElement authuser = driver.findElement(By.name("Name")); //Targetting the searchbox element normal user id
		   authuser.sendKeys("captstone");
			
		   WebElement authuserpwd = driver.findElement(By.name("Pwd")); //Targetting the searchbox element  normal user pwd
		   authuserpwd.sendKeys("info6068");
		   
		   WebElement submituser = driver.findElement(By.xpath("/html/body/form/table/tbody/tr[3]/td[1]/input"));
		   submituser.click(); 
		   
		   driver.switchTo().frame(0);
		   
		   WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
		   WebElement viewFeedbackButton = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html/body/p[5]/button")));
	       viewFeedbackButton.click();
		   
	       Thread.sleep(2000);
	   }
	@Test
	@Order(2)
	 
	   void viewfeedbackpage() throws InterruptedException
	   {
		   //driver.get("http://localhost:8080/TravelApp/User.html");
		   
		   driver.get("http://localhost:8080/TravelApp/");
		   
		   WebElement userlogin = driver.findElement(By.className("loginButton")); //Targetting the searchbox element normal user login
		   userlogin.click();
		  
		   WebElement authuser = driver.findElement(By.name("Name")); //Targetting the searchbox element normal user id
		   authuser.sendKeys("captstone");
			
		   WebElement authuserpwd = driver.findElement(By.name("Pwd")); //Targetting the searchbox element  normal user pwd
		   authuserpwd.sendKeys("info6068");
		   
		   WebElement submituser = driver.findElement(By.xpath("/html/body/form/table/tbody/tr[3]/td[1]/input"));
		   submituser.click(); 
		   
		   driver.switchTo().frame(0);
		   
		   WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
		   WebElement viewFeedbackButton = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html/body/p[5]/button")));
	       viewFeedbackButton.click();
	       
	       Thread.sleep(2000);
	       
	       driver.switchTo().defaultContent();
	       
	       driver.switchTo().frame(2);
	       
	       
	       WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(20));
		   WebElement feedbackHeader = wait1.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html/body/h2")));
	       
	      // WebElement feedbackHeader = driver.findElement(By.xpath("/html/body/h2"));
	        if (feedbackHeader.isDisplayed()) {
	            System.out.println("View Feedback page loaded successfully.");
	        } else {
	            System.out.println("View Feedback page failed to load.");
	            driver.quit();
	            return;
	        }

	        // Validate the content of the view feedback page
	        // For example, check for the presence of feedback elements
	        WebElement feedbackElement = driver.findElement(By.xpath("/html/body/table/tbody/tr[1]/th[3]"));
	        if (feedbackElement.isDisplayed()) {
	            System.out.println("Feedback content is present.");
	            // You can further validate the content if needed
	        } else {
	            System.out.println("Feedback content is not present.");
	        }
	             
	       
		   
	       Thread.sleep(2000);
	   }
	
	@AfterAll
	static void TearDown()
	{
		driver.close(); // After all test, close all test window 
	}

 
} 
