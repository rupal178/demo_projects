package com.project;

import org.junit.Assert;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeDriverService;


@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class UserLogin {

	private static WebDriver driver;
	 
		@BeforeAll	
		static void setup()//main(String[] args) throws InterruptedException
	
		{
		
			System.setProperty("webdriver.chrome.driver","C:\\SeleniumInfo\\chrome_drivers\\chromedriver.exe");
		
			driver = new ChromeDriver();
	    
			driver.get("http://localhost:8080/TravelApp/");
	    
		
			System.setProperty(ChromeDriverService.CHROME_DRIVER_SILENT_OUTPUT_PROPERTY, "true"); 
	    
		}
	   @Test
	   @Order(1)
	   void uservalidlogin() throws InterruptedException
	   {
		   
		   driver.get("http://localhost:8080/TravelApp/");
		   
		   WebElement userlogin = driver.findElement(By.xpath("/html/body/div/div[1]/button[1]")); //Targetting the searchbox element normal user login
		   userlogin.click();
		  
		   WebElement authuser = driver.findElement(By.xpath("/html/body/form/table/tbody/tr[1]/td[2]/input")); //Targetting the searchbox element normal user id
		   authuser.sendKeys("captstone");
			
		   WebElement authuserpwd = driver.findElement(By.xpath("/html/body/form/table/tbody/tr[2]/td[2]/input")); //Targetting the searchbox element  normal user pwd
		   authuserpwd.sendKeys("info6068");
		   
		   WebElement submituser = driver.findElement(By.xpath("/html/body/form/table/tbody/tr[3]/td[1]/input"));
		   submituser.click(); 
		   
		   Thread.sleep(2000);
		   
	   }
		   
	 
	  @Test
	   @Order(2)
	   void userinvalidfields() throws InterruptedException
	   {
		   
		  
		   
		   driver.get("http://localhost:8080/TravelApp/");
		   
		   WebElement userlogin = driver.findElement(By.className("loginButton")); //Targetting the searchbox element normal user login
		   userlogin.click();
		  
		   WebElement authuser = driver.findElement(By.name("Name")); //Targetting the searchbox element normal user id
		   authuser.sendKeys("Caps#1234");
			
		   WebElement authuserpwd = driver.findElement(By.name("Pwd")); //Targetting the searchbox element  normal user pwd
		   authuserpwd.sendKeys("In4@5678");
		   
		   WebElement submituser = driver.findElement(By.xpath("/html/body/form/table/tbody/tr[3]/td[1]/input"));
		   submituser.click(); 
		   
		   Thread.sleep(2000);
		   
		   WebElement invalidlogin = driver.findElement(By.xpath("/html/body/p/font"));
			
			// get the text and compare with expected value
			
			String invalidloginpage = invalidlogin.getText();
			String invalidloginmsg = "SORRY! Invalid username/password, please try again";
			Assert.assertTrue(invalidloginpage.contains(invalidloginmsg));
			
			Thread.sleep(2000);
		   
	   }
	   
	   @Test 
	   @Order(3)
	   void userinvalidPwd() throws InterruptedException
	   {
		   
		  
		   
		   driver.get("http://localhost:8080/TravelApp/");
		   
		   WebElement userlogin = driver.findElement(By.className("loginButton")); //Targetting the searchbox element normal user login
		   userlogin.click();
		  
		   WebElement authuser = driver.findElement(By.name("Name")); //Targetting the searchbox element normal user id
		   authuser.sendKeys("Capstone");
			
		   WebElement authuserpwd = driver.findElement(By.name("Pwd")); //Targetting the searchbox element  normal user pwd
		   authuserpwd.sendKeys("Inf@erttu");
		   
		   WebElement submituser = driver.findElement(By.xpath("/html/body/form/table/tbody/tr[3]/td[1]/input"));
		   submituser.click(); 
		   
		   Thread.sleep(2000);
		   
		   WebElement invalidlogin = driver.findElement(By.xpath("/html/body/p/font"));
			
			// get the text and compare with expected value
			
			String invalidloginpage = invalidlogin.getText();
			String invalidloginmsg = "SORRY! Invalid username/password, please try again";
			Assert.assertTrue(invalidloginpage.contains(invalidloginmsg));
			
			Thread.sleep(2000);
	   }
	   
	   @Test 
	   @Order(4)
	   void userinvalidId() throws InterruptedException
	   {
		   
		  
		   
		   driver.get("http://localhost:8080/TravelApp/");
		   
		   WebElement userlogin = driver.findElement(By.className("loginButton")); //Targetting the searchbox element normal user login
		   userlogin.click();
		  
		   WebElement authuser = driver.findElement(By.name("Name")); //Targetting the searchbox element normal user id
		   authuser.sendKeys("Cart$iii");
			
		   WebElement authuserpwd = driver.findElement(By.name("Pwd")); //Targetting the searchbox element  normal user pwd
		   authuserpwd.sendKeys("info6068");
		   
		   WebElement submituser = driver.findElement(By.xpath("/html/body/form/table/tbody/tr[3]/td[1]/input"));
		   submituser.click(); 
		   
		   Thread.sleep(2000);
		   
		   WebElement invalidlogin = driver.findElement(By.xpath("/html/body/p/font"));
			
			// get the text and compare with expected value
			
			String invalidloginpage = invalidlogin.getText();
			String invalidloginmsg = "SORRY! Invalid username/password, please try again";
			Assert.assertTrue(invalidloginpage.contains(invalidloginmsg));
		   
			Thread.sleep(2000);
	   }
	   
	   @Test
	   @Order(5)
	   void useremptyid() throws InterruptedException
	   {
		   
		   Thread.sleep(2000);
		   
		   driver.get("http://localhost:8080/TravelApp/");
		   
		   WebElement userlogin = driver.findElement(By.className("loginButton")); //Targetting the searchbox element normal user login
		   userlogin.click();
		  
		   WebElement authuser = driver.findElement(By.name("Name")); //Targetting the searchbox element normal user id
		   authuser.sendKeys("");
			
		   WebElement authuserpwd = driver.findElement(By.name("Pwd")); //Targetting the searchbox element  normal user pwd
		   authuserpwd.sendKeys("info6068");
		   
		   WebElement submituser = driver.findElement(By.xpath("/html/body/form/table/tbody/tr[3]/td[1]/input"));
		   submituser.click(); 
		   
		   Thread.sleep(2000);
		   
		   WebElement invalidlogin = driver.findElement(By.xpath("/html/body/p/font"));
			
			// get the text and compare with expected value
			
			String invalidloginpage = invalidlogin.getText();
			String invalidloginmsg = "SORRY! Invalid username/password, please try again";
			Assert.assertTrue(invalidloginpage.contains(invalidloginmsg));
		   
			Thread.sleep(2000);
	   }
	   
	   @Test
	   @Order(6)
	   void useremptypwd() throws InterruptedException
	   {
		   
		   Thread.sleep(2000);
		   
		   driver.get("http://localhost:8080/TravelApp/");
		   
		   WebElement userlogin = driver.findElement(By.className("loginButton")); //Targetting the searchbox element normal user login
		   userlogin.click();
		  
		   WebElement authuser = driver.findElement(By.name("Name")); //Targetting the searchbox element normal user id
		   authuser.sendKeys("capstone");
			
		   WebElement authuserpwd = driver.findElement(By.name("Pwd")); //Targetting the searchbox element  normal user pwd
		   authuserpwd.sendKeys("");
		   
		   WebElement submituser = driver.findElement(By.xpath("/html/body/form/table/tbody/tr[3]/td[1]/input"));
		   submituser.click(); 
		   
		   Thread.sleep(2000);
		   
		   WebElement invalidlogin = driver.findElement(By.xpath("/html/body/p/font"));
			
			// get the text and compare with expected value
			
			String invalidloginpage = invalidlogin.getText();
			String invalidloginmsg = "SORRY! Invalid username/password, please try again";
			Assert.assertTrue(invalidloginpage.contains(invalidloginmsg));
		   
			Thread.sleep(2000);
	   }
	   
	   @Test
	   @Order(7)
	   void useremptyfields() throws InterruptedException
	   {
		   
		   
		   
		   driver.get("http://localhost:8080/TravelApp/");
		   
		   WebElement userlogin = driver.findElement(By.className("loginButton")); //Targetting the searchbox element normal user login
		   userlogin.click();
		  
		   WebElement authuser = driver.findElement(By.name("Name")); //Targetting the searchbox element normal user id
		   authuser.sendKeys("");
			
		   WebElement authuserpwd = driver.findElement(By.name("Pwd")); //Targetting the searchbox element  normal user pwd
		   authuserpwd.sendKeys("");
		   
		   WebElement submituser = driver.findElement(By.xpath("/html/body/form/table/tbody/tr[3]/td[1]/input"));
		   submituser.click(); 
		   
		   Thread.sleep(2000);
		   
		   WebElement invalidlogin = driver.findElement(By.xpath("/html/body/p/font"));
			
			// get the text and compare with expected value
			
			String invalidloginpage = invalidlogin.getText();
			String invalidloginmsg = "SORRY! Invalid username/password, please try again";
			Assert.assertTrue(invalidloginpage.contains(invalidloginmsg));
		   
	   }
	    
	   @Test
	   @Order(8)
	   void resetlogin() throws InterruptedException
	   {
		   
		   driver.get("http://localhost:8080/TravelApp/");
		   
		   WebElement userlogin = driver.findElement(By.className("loginButton")); //Targetting the searchbox element normal user login
		   userlogin.click();
		  
		   WebElement authuser = driver.findElement(By.name("Name")); //Targetting the searchbox element normal user id
		   authuser.sendKeys("captstone");
			
		   WebElement authuserpwd = driver.findElement(By.name("Pwd")); //Targetting the searchbox element  normal user pwd
		   authuserpwd.sendKeys("info6068");
		   
		   Thread.sleep(2000);
			
		   WebElement submitReset = driver.findElement(By.xpath("/html/body/form/table/tbody/tr[3]/td[2]/input"));
		   submitReset.click();  //for reset Button
		   
		   Thread.sleep(2000);
		   
		   WebElement authusernm = driver.findElement(By.name("Name"));
		   
		   Thread.sleep(2000);
		   
		   String authusernmcontent = authusernm.getAttribute("value");
		   	   
		   String expectedauthusernmcontent = "";
		   
		   Assert.assertTrue("The actual content '" + authusernmcontent + "' is not equal to the expected content '" + expectedauthusernmcontent + "'", authusernmcontent.equals(expectedauthusernmcontent));
		    
		   
	   }
	   
	   @Test
	   @Order(9)
	   void userBackLink() throws InterruptedException
	   {
		   
		   driver.get("http://localhost:8080/TravelApp/");
		   
		   WebElement userlogin = driver.findElement(By.xpath("/html/body/div/div[1]/button[1]")); //Targetting the searchbox element normal user login
		   userlogin.click();
		  
		   WebElement authuser = driver.findElement(By.xpath("/html/body/form/table/tbody/tr[1]/td[2]/input")); //Targetting the searchbox element normal user id
		   authuser.sendKeys("captstone123");
			
		   WebElement authuserpwd = driver.findElement(By.xpath("/html/body/form/table/tbody/tr[2]/td[2]/input")); //Targetting the searchbox element  normal user pwd
		   authuserpwd.sendKeys("info6068");
		   
		   WebElement submituser = driver.findElement(By.xpath("/html/body/form/table/tbody/tr[3]/td[1]/input"));
		   submituser.click(); 
		   
		   Thread.sleep(2000);
		   
		   WebElement backlink = driver.findElement(By.xpath("/html/body/p/a"));

		   backlink.click();
		   
		   
		   
		   String actualtravelaplink = driver.getCurrentUrl();
		   String expectedtravelaplink = "http://localhost:8080/TravelApp/Login.html";
		   Assert.assertTrue(actualtravelaplink == expectedtravelaplink );
		  
           Thread.sleep(2000);
		   
	   }
	   @AfterAll
		static void TearDown()
		{
			driver.quit(); // After all test, close all test window 
		}
	
	   
	 
	   
	  
	   
	
		
		
		

	    
	   
	   

}
