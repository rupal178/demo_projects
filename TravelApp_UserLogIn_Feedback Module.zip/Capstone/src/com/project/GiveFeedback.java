package com.project;

import java.time.Duration;

import org.junit.Assert;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeDriverService;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class GiveFeedback 

{

	private static WebDriver driver;

	@BeforeAll
	static void setup()// main(String[] args) throws InterruptedException

	{

		System.setProperty("webdriver.chrome.driver", "C:\\SeleniumInfo\\chrome_drivers\\chromedriver.exe");

		driver = new ChromeDriver();

		driver.get("http://localhost:8080/TravelApp/");

		System.setProperty(ChromeDriverService.CHROME_DRIVER_SILENT_OUTPUT_PROPERTY, "true");

	}

	@Test
	@Order(1)
	void gfPage() throws InterruptedException 
	
	{
		// driver.get("http://localhost:8080/TravelApp/User.html");

		driver.get("http://localhost:8080/TravelApp/");

		WebElement userlogin = driver.findElement(By.className("loginButton")); // Targetting the searchbox element
																				// normal user login
		userlogin.click();

		WebElement authuser = driver.findElement(By.name("Name")); // Targetting the searchbox element normal user id
		authuser.sendKeys("captstone");

		WebElement authuserpwd = driver.findElement(By.name("Pwd")); // Targetting the searchbox element normal user pwd
		authuserpwd.sendKeys("info6068");

		WebElement submituser = driver.findElement(By.xpath("/html/body/form/table/tbody/tr[3]/td[1]/input"));
		submituser.click();

		driver.switchTo().frame(0);

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));

		WebElement giveFeedbackButton = wait
				.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html/body/p[4]/button")));

		Thread.sleep(2000);

		giveFeedbackButton.click();

		Thread.sleep(2000);

	}

	@Test
	@Order(2)
	void gfvalidsubmit() throws InterruptedException 
	
	{
		driver.get("http://localhost:8080/TravelApp/");

		WebElement userlogin = driver.findElement(By.className("loginButton")); // Targetting the searchbox element
																				// normal user login
		userlogin.click();

		WebElement authuser = driver.findElement(By.name("Name")); // Targetting the searchbox element normal user id
		authuser.sendKeys("captstone");

		WebElement authuserpwd = driver.findElement(By.name("Pwd")); // Targetting the searchbox element normal user pwd
		authuserpwd.sendKeys("info6068");

		WebElement submituser = driver.findElement(By.xpath("/html/body/form/table/tbody/tr[3]/td[1]/input"));
		submituser.click();

		driver.switchTo().frame(0);

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));

		WebElement giveFeedbackButton = wait
				.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html/body/p[4]/button")));

		Thread.sleep(2000);

		giveFeedbackButton.click();

		driver.switchTo().defaultContent();

		System.out.println("test checkpint 1");

		driver.switchTo().frame(2);

		WebDriverWait wait5 = new WebDriverWait(driver, Duration.ofSeconds(20));

		WebElement emailInput1 = wait5.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("/html/body/form/table/tbody/tr[2]/td[2]/b/input")));

		Thread.sleep(2000);

		emailInput1.sendKeys("Yourinfo@gmail.com");

		WebElement feedbackInput = driver.findElement(By.name("message"));
		feedbackInput.sendKeys(" update the rates ");

		WebElement submitButton = driver.findElement(By.name("Command"));
		submitButton.click();

		WebElement feedbacksuccs = driver.findElement(By.xpath("/html/body/p/font"));

		String feedbacksuccspg = feedbacksuccs.getText();

		System.out.println(feedbacksuccspg);

		Assert.assertTrue(feedbacksuccspg.contains("Your Feedback submitted successfully"));

		Thread.sleep(2000);
	//	driver.quit();

	}
	
	@Test
	@Order(3)
	void gFBinvalidemail() throws InterruptedException 
	
	{
		driver.get("http://localhost:8080/TravelApp/");

		WebElement userlogin = driver.findElement(By.className("loginButton")); // Targetting the searchbox element
																				// normal user login
		userlogin.click();

		WebElement authuser = driver.findElement(By.name("Name")); // Targetting the searchbox element normal user id
		authuser.sendKeys("captstone");

		WebElement authuserpwd = driver.findElement(By.name("Pwd")); // Targetting the searchbox element normal user pwd
		authuserpwd.sendKeys("info6068");

		WebElement submituser = driver.findElement(By.xpath("/html/body/form/table/tbody/tr[3]/td[1]/input"));
		submituser.click();

		driver.switchTo().frame(0);

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));

		WebElement giveFeedbackButton = wait
				.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html/body/p[4]/button")));

		Thread.sleep(2000);

		giveFeedbackButton.click();

		driver.switchTo().defaultContent();

		System.out.println("test checkpint 1");

		driver.switchTo().frame(2);

		WebDriverWait wait5 = new WebDriverWait(driver, Duration.ofSeconds(20));

		WebElement emailInput1 = wait5.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("/html/body/form/table/tbody/tr[2]/td[2]/b/input")));

		Thread.sleep(2000);

		emailInput1.sendKeys("Yourinfogmail.com");

		WebElement feedbackInput = driver.findElement(By.name("message"));
		feedbackInput.sendKeys("wertyuiop");

		WebElement submitButton = driver.findElement(By.name("Command"));
		submitButton.click();

		WebElement feedbacksuccs = driver.findElement(By.xpath("/html/body/p/font"));

		String feedbacksuccspg = feedbacksuccs.getText();

		System.out.println(feedbacksuccspg);

		Assert.assertTrue(feedbacksuccspg.contains("Incorrect email format"));

		Thread.sleep(2000);
		//driver.quit();

	}
	@Test
	@Order(4)
	void  gFBemptyFB() throws InterruptedException 
	
	{
		driver.get("http://localhost:8080/TravelApp/");

		WebElement userlogin = driver.findElement(By.className("loginButton")); // Targetting the searchbox element
																				// normal user login
		userlogin.click();

		WebElement authuser = driver.findElement(By.name("Name")); // Targetting the searchbox element normal user id
		authuser.sendKeys("captstone");

		WebElement authuserpwd = driver.findElement(By.name("Pwd")); // Targetting the searchbox element normal user pwd
		authuserpwd.sendKeys("info6068");

		WebElement submituser = driver.findElement(By.xpath("/html/body/form/table/tbody/tr[3]/td[1]/input"));
		submituser.click();

		driver.switchTo().frame(0);

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));

		WebElement giveFeedbackButton = wait
				.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html/body/p[4]/button")));

		Thread.sleep(2000);

		giveFeedbackButton.click();

		driver.switchTo().defaultContent();

		System.out.println("test checkpint 1");

		driver.switchTo().frame(2);

		WebDriverWait wait5 = new WebDriverWait(driver, Duration.ofSeconds(20));

		WebElement emailInput1 = wait5.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("/html/body/form/table/tbody/tr[2]/td[2]/b/input")));

		Thread.sleep(2000);

		emailInput1.sendKeys("Yourinfo@gmail.com");

		WebElement feedbackInput = driver.findElement(By.name("message"));
		feedbackInput.sendKeys("");

		WebElement submitButton = driver.findElement(By.name("Command"));
		submitButton.click();
		
		Thread.sleep(2000);

		String alerttext = driver.switchTo().alert().getText();
		
		driver.switchTo().alert().accept();
		
		//WebElement feedbacksuccs = driver.findElement(By.xpath("/html/body/p/font"));
		//String alerttext = alert.getText()
		System.out.println(alerttext);


		//String feedbacksuccspg = feedbacksuccs.getText();

		//System.out.println(feedbacksuccspg);

		Assert.assertTrue(alerttext.contains("Feedback is mandatory"));

		Thread.sleep(2000);
		//driver.quit();

	}
	
	@Test
	@Order(5)
	void  gFBemptyid() throws InterruptedException 
	
	{
		driver.get("http://localhost:8080/TravelApp/");

		WebElement userlogin = driver.findElement(By.className("loginButton")); // Targetting the searchbox element
																				// normal user login
		userlogin.click();

		WebElement authuser = driver.findElement(By.name("Name")); // Targetting the searchbox element normal user id
		authuser.sendKeys("captstone");

		WebElement authuserpwd = driver.findElement(By.name("Pwd")); // Targetting the searchbox element normal user pwd
		authuserpwd.sendKeys("info6068");

		WebElement submituser = driver.findElement(By.xpath("/html/body/form/table/tbody/tr[3]/td[1]/input"));
		submituser.click();

		driver.switchTo().frame(0);

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));

		WebElement giveFeedbackButton = wait
				.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html/body/p[4]/button")));

		Thread.sleep(2000);

		giveFeedbackButton.click();

		driver.switchTo().defaultContent();

		System.out.println("test checkpint 1");

		driver.switchTo().frame(2);

		WebDriverWait wait5 = new WebDriverWait(driver, Duration.ofSeconds(20));

		WebElement emailInput1 = wait5.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("/html/body/form/table/tbody/tr[2]/td[2]/b/input")));

		Thread.sleep(2000);

		emailInput1.sendKeys("");
		
		WebElement feedbackInput = driver.findElement(By.name("message"));
		feedbackInput.sendKeys("site is good");


		//WebElement feedbackInput = driver.findElement(By.name("message"));
		//feedbackInput.sendKeys("");

		WebElement submitButton = driver.findElement(By.name("Command"));
		submitButton.click();
		
		Thread.sleep(2000);

		String alerttext = driver.switchTo().alert().getText();
		
		driver.switchTo().alert().accept();
		
		//WebElement feedbacksuccs = driver.findElement(By.xpath("/html/body/p/font"));
		//String alerttext = alert.getText()
		System.out.println(alerttext);


		//String feedbacksuccspg = feedbacksuccs.getText();

		//System.out.println(feedbacksuccspg);

		Assert.assertTrue(alerttext.contains("Please provide your mail id."));

		Thread.sleep(2000);
		//driver.quit();

	}
	@Test
	@Order(6)
	void  gFBemptyfields() throws InterruptedException 
	
	{
		driver.get("http://localhost:8080/TravelApp/");

		WebElement userlogin = driver.findElement(By.className("loginButton")); // Targetting the searchbox element
																				// normal user login
		userlogin.click();

		WebElement authuser = driver.findElement(By.name("Name")); // Targetting the searchbox element normal user id
		authuser.sendKeys("captstone");

		WebElement authuserpwd = driver.findElement(By.name("Pwd")); // Targetting the searchbox element normal user pwd
		authuserpwd.sendKeys("info6068");

		WebElement submituser = driver.findElement(By.xpath("/html/body/form/table/tbody/tr[3]/td[1]/input"));
		submituser.click();

		driver.switchTo().frame(0);

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));

		WebElement giveFeedbackButton = wait
				.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html/body/p[4]/button")));

		Thread.sleep(2000);

		giveFeedbackButton.click();

		driver.switchTo().defaultContent();

		System.out.println("test checkpint 1");

		driver.switchTo().frame(2);

		WebDriverWait wait5 = new WebDriverWait(driver, Duration.ofSeconds(20));

	    WebElement emailInput1 = wait5.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("/html/body/form/table/tbody/tr[2]/td[2]/b/input")));

		Thread.sleep(2000);

		emailInput1.sendKeys("");
		
		WebElement feedbackInput = driver.findElement(By.name("message"));
		feedbackInput.sendKeys("");


		//WebElement feedbackInput = driver.findElement(By.name("message"));
		//feedbackInput.sendKeys("");

		WebElement submitButton = driver.findElement(By.name("Command"));
		submitButton.click();
		
		Thread.sleep(2000);

		String alerttext = driver.switchTo().alert().getText();
		
		driver.switchTo().alert().accept();
		
		//WebElement feedbacksuccs = driver.findElement(By.xpath("/html/body/p/font"));
		//String alerttext = alert.getText()
		System.out.println(alerttext);


		//String feedbacksuccspg = feedbacksuccs.getText();

		//System.out.println(feedbacksuccspg);

		Assert.assertTrue(alerttext.contains("Please provide your mail id."));

		Thread.sleep(2000);
		//driver.quit();

	}
	@Test
	@Order(7)
	void  gFBclear() throws InterruptedException 
	{
		driver.get("http://localhost:8080/TravelApp/");

		WebElement userlogin = driver.findElement(By.className("loginButton")); // Targetting the searchbox element
																				// normal user login
		userlogin.click();

		WebElement authuser = driver.findElement(By.name("Name")); // Targetting the searchbox element normal user id
		authuser.sendKeys("captstone");

		WebElement authuserpwd = driver.findElement(By.name("Pwd")); // Targetting the searchbox element normal user pwd
		authuserpwd.sendKeys("info6068");

		WebElement submituser = driver.findElement(By.xpath("/html/body/form/table/tbody/tr[3]/td[1]/input"));
		submituser.click();

		driver.switchTo().frame(0);

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));

		WebElement giveFeedbackButton = wait
				.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html/body/p[4]/button")));

		Thread.sleep(2000);

		giveFeedbackButton.click();

		driver.switchTo().defaultContent();

		System.out.println("test checkpint 1");

		driver.switchTo().frame(2);

		WebDriverWait wait5 = new WebDriverWait(driver, Duration.ofSeconds(20));

		WebElement emailInput1 = wait5.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("/html/body/form/table/tbody/tr[2]/td[2]/b/input")));

		Thread.sleep(2000);

		emailInput1.sendKeys("Yourinfo@gmail.com");

		WebElement feedbackInput = driver.findElement(By.name("message"));
		feedbackInput.sendKeys(" update the rates ");

		WebElement clearButton = driver.findElement(By.name("Clear"));
		clearButton.click();

		WebElement userid = driver.findElement((By.xpath("/html/body/form/table/tbody/tr[2]/td[2]/b/input")));
		   
		   Thread.sleep(2000);
		   
		   String useridcontent = userid.getAttribute("value");
		   	   
		   String expectedauthuseridcontent = "";
		   
		   Assert.assertTrue("The actual content '" + useridcontent + "' is  equal to the expected content '" + expectedauthuseridcontent + "'", useridcontent.equals(expectedauthuseridcontent));
		    
		   
		
		
		Thread.sleep(2000);
	//	driver.quit();
		
		
	}
	
	@Test
	@Order(8)
	void gfCheckBackLink() throws InterruptedException
	
	{
		driver.get("http://localhost:8080/TravelApp/");

		WebElement userlogin = driver.findElement(By.className("loginButton")); // Targetting the searchbox element
																				// normal user login
		userlogin.click();

		WebElement authuser = driver.findElement(By.name("Name")); // Targetting the searchbox element normal user id
		authuser.sendKeys("captstone");

		WebElement authuserpwd = driver.findElement(By.name("Pwd")); // Targetting the searchbox element normal user pwd
		authuserpwd.sendKeys("info6068");

		WebElement submituser = driver.findElement(By.xpath("/html/body/form/table/tbody/tr[3]/td[1]/input"));
		submituser.click();

		driver.switchTo().frame(0);

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));

		WebElement giveFeedbackButton = wait
				.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html/body/p[4]/button")));

		Thread.sleep(2000);

		giveFeedbackButton.click();

		driver.switchTo().defaultContent();

	//	System.out.println("test checkpint 1");

		driver.switchTo().frame(2);

		WebDriverWait wait5 = new WebDriverWait(driver, Duration.ofSeconds(20));

		WebElement emailInput1 = wait5.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("/html/body/form/table/tbody/tr[2]/td[2]/b/input")));

		Thread.sleep(2000);

		emailInput1.sendKeys("Yourinfo@gmail.com");

		WebElement feedbackInput = driver.findElement(By.name("message"));
		feedbackInput.sendKeys(" update the rates ");

		WebElement submitButton = driver.findElement(By.name("Command"));
		submitButton.click();

		Thread.sleep(2000);
		
		WebElement fedbkbackbtn = driver.findElement(By.xpath("/html/body/center/a"));

		fedbkbackbtn.click();
		
		Thread.sleep(2000);
		
		//driver.switchTo().frame(0);
		
		//WebElement givefedbackpage = driver.findElement(By.xpath("/html/body/p/font/text()[1]"));
		
		WebElement givefedbackpage = driver.findElement(By.xpath("//p/font[contains(text(), 'Please drop us a line')]"));
		
		
	    String givefedbackpagemsg = givefedbackpage.getText();

		System.out.println(givefedbackpagemsg);

		Assert.assertTrue(givefedbackpagemsg.contains("Please drop us a line"));

		Thread.sleep(2000);
	//	driver.quit();

	}
	

	@AfterAll
	static void TearDown() 
	{
		driver.close(); // After all test, close all test window
	}

}