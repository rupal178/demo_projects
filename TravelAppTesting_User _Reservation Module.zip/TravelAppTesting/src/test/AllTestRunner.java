package test;

import java.util.ArrayList;
import java.util.List;

import org.junit.runner.Computer;
import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.RunListener;

public class AllTestRunner {

	public static List<Class> getAllViewRoutes(int count) {
		List<Class> lst = new ArrayList<>();
		for (int i = 0; i < count; ++i) {
			lst.add(TS_VR_001.class);
			lst.add(TS_VR_002.class);
		}
		return lst;
	}

	public static List<Class> getAllBookTickets(int count) {
		List<Class> lst = new ArrayList<>();
		for (int i = 0; i < count; ++i) {
			lst.add(TS_BT_001.class);
			lst.add(TS_BT_002.class);
			lst.add(TS_BT_003.class);
			lst.add(TS_BT_004.class);
			lst.add(TS_BT_005.class);
			lst.add(TS_BT_006.class);
			lst.add(TS_BT_007.class);
			lst.add(TS_BT_008.class);
			lst.add(TS_BT_009.class);
			lst.add(TS_BT_010.class);
			lst.add(TS_BT_011.class);
			lst.add(TS_BT_012.class);
			lst.add(TS_BT_013.class);
			lst.add(TS_BT_014.class);
			lst.add(TS_BT_015.class);
		}
		return lst;
	}

	public static List<Class> getAllCancelTickets(int count) {
		List<Class> lst = new ArrayList<>();
		for (int i = 0; i < count; ++i) {
			lst.add(TS_CT_001.class);
			lst.add(TS_CT_002.class);
			lst.add(TS_CT_003.class);
		}
		return lst;
	}

	public static void main(String[] args) {
		List<Class> lst = new ArrayList<>();
		lst.addAll(getAllViewRoutes(5));
		lst.addAll(getAllBookTickets(5));
		lst.addAll(getAllCancelTickets(5));
		Class classes[] = new Class[lst.size()];
		for (int i = 0; i < classes.length; ++i)
			classes[i] = lst.get(i);
		List<Result> faileds = new ArrayList<>();
		for (Class cls : lst) {
			Result result = JUnitCore.runClasses(cls);
			System.out.println("Test : " + cls.getName() + " -> " + (result.wasSuccessful() ? "Ok" : "Failed ****************"));
			if ( !result.wasSuccessful() )
				faileds.add(result);
		}
		for ( Result rs : faileds ) {
			System.out.println(rs.getFailures().getLast());
		}
	}
}