package test;

import static org.junit.jupiter.api.Assertions.fail;

import java.io.File;
import java.io.FileWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class TS_BT_004 {
	private WebDriver driver;
	private final String applink = "http://localhost:8080/TravelApp/";
	private final String user_id = "capstone";
	private final String user_password = "info6068";
	private final String target_String = "Welcome to EasyJourney: Online bus reservation.";
	private final String frameButtons = "leftTop", frameContent = "tgt";
	private final String testButtonName = "Book Tickets";

	@Before
	public void create() {
		this.driver = new ChromeDriver();

	}

	public void pushTicketIdIntoFile(String ticketID) {
		try {
			String fileName = "TicketIDs.txt";
			File fl = new File(fileName);
			if (!fl.exists())
				fl.createNewFile();
			ticketID += "\n";
			Files.write(Paths.get(fileName), ticketID.getBytes(), StandardOpenOption.APPEND);
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
			ex.printStackTrace();
			fail("Couldn't save itcket id into file ");
		}
	}

	public String popTicketIdFromFile() {
		try {
			String fileName = "TicketIDs.txt";
			File ticketId = new File(fileName);
			Scanner sc = new Scanner(ticketId);
			List<String> all = new ArrayList<>();
			String retId = "";
			Boolean found = false;
			while (sc.hasNextLine()) {
				if (!found) {
					retId = sc.nextLine();
					found = true;
				} else {
					all.add(sc.nextLine());
				}
			}
			sc.close();
			if (!found)
				fail("No ticked it in queue to delete");
			FileWriter myWriter = new FileWriter(fileName);
			for (String st : all) {
				myWriter.append(st + "\n");
			}
			myWriter.close();
			return retId;
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
			ex.printStackTrace();
			fail("Queue file failed");
		}
		return "";
	}

	/*
	 * public void waitByXpath(String xpath) { WebDriverWait wait = new
	 * WebDriverWait(driver, Duration.ofSeconds(10));
	 * wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpath))); }
	 */

	public void clickByCss(String css) {
		driver.findElement(By.cssSelector(css)).click();
	}

	public void clickByXpath(String xpath) {
		driver.findElement(By.xpath(xpath)).click();
	}

	public void sendKeyByCss(String css, String key) {
		driver.findElement(By.cssSelector(css)).sendKeys(key);
	}

	public String getSourceFrame(String frameName, int currentDepth) {
		try {
			for (int i = 0; i < currentDepth; ++i)
				driver.switchTo().parentFrame();
			driver.switchTo().frame(frameName);
			return driver.getPageSource();
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
			ex.printStackTrace();
		}
		fail("Could not find frame to get source test");
		return frameName;
	}

	public void clickButtonByNameFrame(String frameName, String xpath, String name) {
		try {
			driver.switchTo().parentFrame();
			driver.switchTo().frame(frameName);
			List<WebElement> elements = driver.findElements(By.xpath(xpath));
			for (WebElement element : elements) {
				if (element.getText().equals(name)) {
					element.click();
					break;
				}
			}
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
			ex.printStackTrace();
		}
	}

	List<WebElement> getElementsByClassInFrame(String frameName, String className) {
		List<WebElement> elements = null;
		try {
			driver.switchTo().parentFrame();
			driver.switchTo().frame(frameName);
			elements = driver.findElements(By.className(className));
			return elements;
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
			ex.printStackTrace();
		}
		fail("Something bad happended while getting elements");
		return elements;
	}

	List<WebElement> getElementsByClass(String className) {
		List<WebElement> elements = null;
		try {
			elements = driver.findElements(By.className(className));
			return elements;
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
			ex.printStackTrace();
		}
		fail("Something bad happended while getting elements");
		return elements;
	}

	public void openApplicationAndLogin() {
		driver.get(applink);
		clickByCss("Button[class='loginButton']");
		sendKeyByCss("input[name='Name']", user_id);
		sendKeyByCss("input[name='Pwd']", user_password);
		clickByCss("input[value='Submit']");
		String text = getSourceFrame("tgt", 0);
		Assert.assertTrue(text.contains(target_String));
	}

	public void verifyBookTicketPageOpened() {
		clickButtonByNameFrame(frameButtons, "//button[@type='button']", testButtonName);
		String content = getSourceFrame(frameContent, 1);
		String targetString = "Book Tickets Now";
		Assert.assertTrue("Book Tickets Now page not found.", content.contains(targetString));
	}

	public void fillupFormAndCheckAvailability() {
		Select fromDD = new Select(driver.findElement(By.name("From")));
		fromDD.selectByVisibleText("London");
		Select toDD = new Select(driver.findElement(By.name("To")));
		toDD.selectByVisibleText("Montreal");
		WebElement journeyDate = driver.findElement(By.id("datepicker"));
		journeyDate.sendKeys("01/31/2024");
		journeyDate.sendKeys(Keys.RETURN);
		Select busType = new Select(driver.findElement(By.name("BusType")));
		busType.selectByVisibleText("any");
		WebElement passengers = driver.findElement(By.name("NoPass"));
		passengers.sendKeys("1");
		WebElement submitButton = driver.findElement(By.xpath("//input[@value='Check Availability']"));
		submitButton.click();
	}

	public void selectBusAndBookNow() {
		WebElement radioButton = driver.findElement(By.xpath("//input[@value='R3_T3_B3']"));
		radioButton.click();
		WebElement bookNowButton = driver.findElement(By.xpath("//input[@value='Book Now']"));
		bookNowButton.click();
	}

	public void selectSeatAndContinue() {
		Select boardingPoint = new Select(driver.findElement(By.name("BPoint")));
		boardingPoint.selectByVisibleText("Guy");
		List<WebElement> available = driver.findElements(By.xpath("//img[@src='Images/availableSeat.jpg']"));
		available.get(0).click();
		WebElement conBtn = driver.findElement(By.xpath("//img[@src='Images/Menu/Continue1.jpg']"));
		conBtn.click();
		// String source = getSourceFrame ( frameContent, 1 );
		// System.out.println ( source );
	}

	public void fillCustomerDetailsAndSaveSubmit() {
		String source = getSourceFrame ( frameContent, 1 );
		String trgt = "Customer Info";
		Assert.assertTrue("Customer info page not opened", source.contains(trgt));
		// System.out.println ( source );
	}

	@Test
	public void canContinueWithValidSeatSelect() {
		openApplicationAndLogin();
		verifyBookTicketPageOpened();
		fillupFormAndCheckAvailability();
		selectBusAndBookNow();
		selectSeatAndContinue();
		fillCustomerDetailsAndSaveSubmit();
	}

	@After
	public void cleanup() {
		driver.quit();
	}
}
