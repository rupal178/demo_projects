package test;

import static org.junit.jupiter.api.Assertions.fail;

import java.util.List;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class TS_VR_001 {
	private WebDriver driver;
	private final String applink = "http://localhost:8080/TravelApp/";
	private final String user_id = "capstone";
	private final String user_password = "info6068";
	private final String target_String = "Welcome to EasyJourney: Online bus reservation.";
	private final String frameButtons = "leftTop", frameContent = "tgt";
	private final String testButtonName = "View Routes";

	@Before
	public void create() {
		this.driver = new ChromeDriver();

	}

	/*
	 * public void waitByXpath(String xpath) { WebDriverWait wait = new
	 * WebDriverWait(driver, Duration.ofSeconds(10));
	 * wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpath))); }
	 */

	public void clickByCss(String css) {
		driver.findElement(By.cssSelector(css)).click();
	}

	public void clickByXpath(String xpath) {
		driver.findElement(By.xpath(xpath)).click();
	}

	public void sendKeyByCss(String css, String key) {
		driver.findElement(By.cssSelector(css)).sendKeys(key);
	}

	public String getSourceFrame(String frameName) {
		try {
			driver.switchTo().frame(frameName);
			return driver.getPageSource();
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
			ex.printStackTrace();
		}
		fail("Could not find frame to get source test");
		return frameName;
	}

	public void clickButtonByNameFrame(String frameName, String xpath, String name) {
		try {
			driver.switchTo().parentFrame();
			driver.switchTo().frame(frameName);
			List<WebElement> elements = driver.findElements(By.xpath(xpath));
			for (WebElement element : elements) {
				if (element.getText().equals(name)) {
					element.click();
					break;
				}
			}
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
			ex.printStackTrace();
		}
	}

	List<WebElement> getElementsByClassInFrame(String frameName, String className) {
		List<WebElement> elements = null;
		try {
			driver.switchTo().parentFrame();
			driver.switchTo().frame(frameName);
			elements = driver.findElements(By.className(className));
			return elements;
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
			ex.printStackTrace();
		}
		fail("Something bad happended while getting elements");
		return elements;
	}

	List<WebElement> getElementsByClass(String className) {
		List<WebElement> elements = null;
		try {
			elements = driver.findElements(By.className(className));
			return elements;
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
			ex.printStackTrace();
		}
		fail("Something bad happended while getting elements");
		return elements;
	}

	public void openApplicationAndLogin() {
		driver.get(applink);
		clickByCss("Button[class='loginButton']");
		sendKeyByCss("input[name='Name']", user_id);
		sendKeyByCss("input[name='Pwd']", user_password);
		clickByCss("input[value='Submit']");
		String text = getSourceFrame("tgt");
		Assert.assertTrue(text.contains(target_String));
	}

	public void verifyRoutesAreVisible() {
		clickButtonByNameFrame(frameButtons, "//button[@type='button']", testButtonName);
		List<WebElement> elements = getElementsByClassInFrame(frameContent, "row_even");
		elements.addAll(getElementsByClassInFrame(frameContent, "row_odd"));
		String need[] = { "London Montreal B3 21:00:00 09:00:00 600 2024-01-31",
				"London Naigra B2 18:00:00 19:00:00 450 2024-01-15",
				"Montreal Cornwall B3 11:00:00 19:00:00 234 2024-05-16",
				"Toronto Woodstock B1 11:00:00 23:00:00 350 2024-07-25",
				"London Toronto B3 21:00:00 09:00:00 600 2024-02-27",
				"London Kingston B1 19:00:00 08:00:00 450 2024-02-20",
				"London Ottawa B3 08:00:00 08:30:00 600 2024-04-27",
				"Toronto Windsor B3 11:00:00 19:00:00 234 2024-11-27", };
		Boolean result[] = { false, false, false, false, false, false, false, false, };
		for (WebElement elem : elements) {
			String text = elem.getText();
			for ( int i = 0; i < need.length; ++i ) {
				if ( text.contains(need[i]) ) {
					result[i] = true;
					break;
				}
			}
		}
		for ( int i = 0; i < need.length; ++i ) {
			if ( !result[i] ) {
				fail ( "Cound't find " + need[i] + " in page." );
			}
		}
	}

	@Test
	public void canViewAllAvailableRoutes() {
		openApplicationAndLogin();
		verifyRoutesAreVisible();
	}

	@After
	public void cleanup() {
		driver.quit();
	}
}
