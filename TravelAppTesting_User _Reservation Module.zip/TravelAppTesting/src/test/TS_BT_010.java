package test;

import static org.junit.jupiter.api.Assertions.fail;

import java.io.File;
import java.io.FileWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

public class TS_BT_010 {
	private WebDriver driver;
	private final String applink = "http://localhost:8080/TravelApp/";
	private final String user_id = "capstone";
	private final String user_password = "info6068";
	private final String target_String = "Welcome to EasyJourney: Online bus reservation.";
	private final String frameButtons = "leftTop", frameContent = "tgt";
	private final String testButtonName = "Book Tickets";

	private String defaultTab;

	@Before
	public void create() {
		this.driver = new ChromeDriver();

	}

	public void pushTicketIdIntoFile(String ticketID) {
		try {
			String fileName = "TicketIDs.txt";
			File fl = new File(fileName);
			if (!fl.exists())
				fl.createNewFile();
			ticketID += "\n";
			Files.write(Paths.get(fileName), ticketID.getBytes(), StandardOpenOption.APPEND);
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
			ex.printStackTrace();
			fail("Couldn't save itcket id into file ");
		}
	}

	public String popTicketIdFromFile() {
		try {
			String fileName = "TicketIDs.txt";
			File ticketId = new File(fileName);
			Scanner sc = new Scanner(ticketId);
			List<String> all = new ArrayList<>();
			String retId = "";
			Boolean found = false;
			while (sc.hasNextLine()) {
				if (!found) {
					retId = sc.nextLine();
					found = true;
				} else {
					all.add(sc.nextLine());
				}
			}
			sc.close();
			if (!found)
				fail("No ticked it in queue to delete");
			FileWriter myWriter = new FileWriter(fileName);
			for (String st : all) {
				myWriter.append(st + "\n");
			}
			myWriter.close();
			return retId;
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
			ex.printStackTrace();
			fail("Queue file failed");
		}
		return "";
	}

	/*
	 * public void waitByXpath(String xpath) { WebDriverWait wait = new
	 * WebDriverWait(driver, Duration.ofSeconds(10));
	 * wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpath))); }
	 */

	public void clickByCss(String css) {
		driver.findElement(By.cssSelector(css)).click();
	}

	public void clickByXpath(String xpath) {
		driver.findElement(By.xpath(xpath)).click();
	}

	public void sendKeyByCss(String css, String key) {
		driver.findElement(By.cssSelector(css)).sendKeys(key);
	}

	public String getSourceFrame(String frameName, int currentDepth) {
		try {
			for (int i = 0; i < currentDepth; ++i)
				driver.switchTo().parentFrame();
			driver.switchTo().frame(frameName);
			return driver.getPageSource();
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
			ex.printStackTrace();
		}
		fail("Could not find frame to get source test");
		return frameName;
	}

	public void clickButtonByNameFrame(String frameName, String xpath, String name) {
		try {
			driver.switchTo().parentFrame();
			driver.switchTo().frame(frameName);
			List<WebElement> elements = driver.findElements(By.xpath(xpath));
			for (WebElement element : elements) {
				if (element.getText().equals(name)) {
					element.click();
					break;
				}
			}
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
			ex.printStackTrace();
		}
	}

	List<WebElement> getElementsByClassInFrame(String frameName, String className) {
		List<WebElement> elements = null;
		try {
			driver.switchTo().parentFrame();
			driver.switchTo().frame(frameName);
			elements = driver.findElements(By.className(className));
			return elements;
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
			ex.printStackTrace();
		}
		fail("Something bad happended while getting elements");
		return elements;
	}

	List<WebElement> getElementsByClass(String className) {
		List<WebElement> elements = null;
		try {
			elements = driver.findElements(By.className(className));
			return elements;
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
			ex.printStackTrace();
		}
		fail("Something bad happended while getting elements");
		return elements;
	}

	public void openApplicationAndLogin() {
		driver.get(applink);
		clickByCss("Button[class='loginButton']");
		sendKeyByCss("input[name='Name']", user_id);
		sendKeyByCss("input[name='Pwd']", user_password);
		clickByCss("input[value='Submit']");
		String text = getSourceFrame("tgt", 0);
		Assert.assertTrue(text.contains(target_String));
	}

	public void verifyBookTicketPageOpened() {
		clickButtonByNameFrame(frameButtons, "//button[@type='button']", testButtonName);
		String content = getSourceFrame(frameContent, 1);
		String targetString = "Book Tickets Now";
		Assert.assertTrue("Book Tickets Now page not found.", content.contains(targetString));
	}

	public void fillupFormAndCheckAvailability() {
		Select fromDD = new Select(driver.findElement(By.name("From")));
		fromDD.selectByVisibleText("London");
		Select toDD = new Select(driver.findElement(By.name("To")));
		toDD.selectByVisibleText("Montreal");
		WebElement journeyDate = driver.findElement(By.id("datepicker"));
		journeyDate.sendKeys("01/31/2024");
		journeyDate.sendKeys(Keys.RETURN);
		Select busType = new Select(driver.findElement(By.name("BusType")));
		busType.selectByVisibleText("any");
		WebElement passengers = driver.findElement(By.name("NoPass"));
		passengers.sendKeys("1");
		WebElement submitButton = driver.findElement(By.xpath("//input[@value='Check Availability']"));
		submitButton.click();
	}

	public void selectBusAndBookNow() {
		WebElement radioButton = driver.findElement(By.xpath("//input[@value='R3_T3_B3']"));
		radioButton.click();
		WebElement bookNowButton = driver.findElement(By.xpath("//input[@value='Book Now']"));
		bookNowButton.click();
	}

	public void selectSeatAndContinue() {
		Select boardingPoint = new Select(driver.findElement(By.name("BPoint")));
		boardingPoint.selectByVisibleText("Guy");
		List<WebElement> available = driver.findElements(By.xpath("//img[@src='Images/availableSeat.jpg']"));
		available.get(0).click();
		WebElement conBtn = driver.findElement(By.xpath("//img[@src='Images/Menu/Continue1.jpg']"));
		conBtn.click();
		// String source = getSourceFrame ( frameContent, 1 );
		// System.out.println ( source );
	}

	public void fillCustomerDetailsAndSaveSubmit() {
		WebElement customerName = driver.findElement(By.name("CustomerName"));
		customerName.sendKeys("Abcd Efgh");
		WebElement phoneNumber = driver.findElement(By.name("PhoneNumber"));
		phoneNumber.sendKeys("1695830941");
		WebElement address = driver.findElement(By.name("Address"));
		address.sendKeys("123 Abcdef Ghij");
		WebElement location = driver.findElement(By.name("Location"));
		location.sendKeys("Abcdefgh");
		WebElement email = driver.findElement(By.name("email"));
		email.sendKeys("abcdefghij@something.com");
		Select gender = new Select(driver.findElement(By.name("Gender")));
		gender.selectByVisibleText("Female");
		WebElement saveButton = driver.findElement(By.className("WinButton"));
		saveButton.click();
		Wait<WebDriver> wait = new WebDriverWait(driver, Duration.ofSeconds(2));
		wait.until(d -> ExpectedConditions.alertIsPresent());
		Alert alert = driver.switchTo().alert();
		String firstAlrtText = alert.getText();
		String firstAlrtTrgt = "The provided information will be saved";
		Assert.assertTrue("Info save didn't match", firstAlrtText.contains(firstAlrtTrgt));
		alert.accept();
		wait.until(d -> ExpectedConditions.alertIsPresent());
		alert = driver.switchTo().alert();
		String secondAlrtText = alert.getText();
		String secondAlrtTrgts[] = { "Save customer information", "SaveCustomerInfo.jsp?CustomerName=", "&PhoneNumber=",
				"&Address=", "&Location=", "&email=" };
		for (String sat : secondAlrtTrgts) {
			if (!secondAlrtText.contains(sat)) {
				fail("Info save querry didn't match");
			}
		}
		alert.accept();
		String source = getSourceFrame(frameContent, 1);
		Assert.assertTrue("Customer info saved successfully is not present after saving",
				source.contains("Customer info saved successfully"));
		// saving default tab info
		defaultTab = driver.getWindowHandle();
		WebElement cntBtn = driver.findElement(By.xpath("//img[@src='Images/Menu/Continue1.jpg']"));
		cntBtn.click();
	}

	public void openPaymentTabAndFullSubmit() {
		Set<String> tabs = driver.getWindowHandles();
		// System.out.println ( defaultTab );
		for (String t : tabs) {
			if (!t.equals(defaultTab)) {
				driver.switchTo().window(t);
				break;
			}
		}
		Select paymentMode = new Select(driver.findElement(By.name("PaymentMode")));
		paymentMode.selectByVisibleText("Credit Card");
		WebElement bankName = driver.findElement(By.name("BankName"));
		bankName.sendKeys("ISSB");
		WebElement cardNo = driver.findElement(By.name("CardNo"));
		cardNo.sendKeys("1234567890123456");
		WebElement saveButton = driver.findElement(By.className("WinButton"));
		saveButton.click();
		Wait<WebDriver> wait = new WebDriverWait(driver, Duration.ofSeconds(5));
		String fxp = "/html/body/form/div/p/font/i";
		wait.until(d -> ExpectedConditions.visibilityOf(driver.findElement(By.xpath(fxp))));
		String source = driver.getPageSource();
		// System.out.println(source);
		Assert.assertTrue("Payment details saved successfully not present after saving",
				source.contains("Payment details saved successfully"));
	}

	@Test
	public void canSaveValidPaymentDetails() {
		openApplicationAndLogin();
		verifyBookTicketPageOpened();
		fillupFormAndCheckAvailability();
		selectBusAndBookNow();
		selectSeatAndContinue();
		fillCustomerDetailsAndSaveSubmit();
		openPaymentTabAndFullSubmit();
	}

	@After
	public void cleanup() {
		driver.quit();
	}
}
