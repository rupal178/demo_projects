package test;

import static org.junit.jupiter.api.Assertions.fail;

import java.util.List;
import java.util.Set;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class TS_VR_002 {
	private WebDriver driver;
	private final String applink = "http://localhost:8080/TravelApp/";
	private final String user_id = "capstone";
	private final String user_password = "info6068";
	private final String target_String = "Welcome to EasyJourney: Online bus reservation.";
	private final String frameButtons = "leftTop", frameContent = "tgt";
	private final String testButtonName = "View Routes";

	@Before
	public void create() {
		this.driver = new ChromeDriver();

	}

	/*
	 * public void waitByXpath(String xpath) { WebDriverWait wait = new
	 * WebDriverWait(driver, Duration.ofSeconds(10));
	 * wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpath))); }
	 */

	public void clickByCss(String css) {
		driver.findElement(By.cssSelector(css)).click();
	}

	public void clickByXpath(String xpath) {
		driver.findElement(By.xpath(xpath)).click();
	}

	public void sendKeyByCss(String css, String key) {
		driver.findElement(By.cssSelector(css)).sendKeys(key);
	}

	public String getSourceFrame(String frameName) {
		try {
			driver.switchTo().frame(frameName);
			return driver.getPageSource();
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
			ex.printStackTrace();
		}
		fail("Could not find frame to get source test");
		return frameName;
	}

	public void clickButtonByNameFrame(String frameName, String xpath, String name) {
		try {
			driver.switchTo().parentFrame();
			driver.switchTo().frame(frameName);
			List<WebElement> elements = driver.findElements(By.xpath(xpath));
			for (WebElement element : elements) {
				if (element.getText().equals(name)) {
					element.click();
					break;
				}
			}
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
			ex.printStackTrace();
		}
	}

	List<WebElement> getElementsByClassInFrame(String frameName, String className) {
		List<WebElement> elements = null;
		try {
			driver.switchTo().parentFrame();
			driver.switchTo().frame(frameName);
			elements = driver.findElements(By.className(className));
			return elements;
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
			ex.printStackTrace();
		}
		fail("Something bad happended while getting elements");
		return elements;
	}

	List<WebElement> getElementsByClass (String className) {
		List<WebElement> elements = null;
		try {
			elements = driver.findElements(By.className(className));
			return elements;
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
			ex.printStackTrace();
		}
		fail("Something bad happended while getting elements");
		return elements;
	}

	public void openApplicationAndLogin() {
		driver.get(applink);
		clickByCss("Button[class='loginButton']");
		sendKeyByCss("input[name='Name']", user_id);
		sendKeyByCss("input[name='Pwd']", user_password);
		clickByCss("input[value='Submit']");
		String text = getSourceFrame("tgt");
		Assert.assertTrue(text.contains(target_String));
	}

	public void verifyRoutesAreVisible() {
		clickButtonByNameFrame(frameButtons, "//button[@type='button']", testButtonName);
	}

	public void verifyPickupPoints() {
		List<WebElement> elements = getElementsByClassInFrame(frameContent, "row_even");
		elements.addAll(getElementsByClassInFrame(frameContent, "row_odd"));
		WebElement targetElement = null;
		for (WebElement elem : elements) {
			String text = elem.getText();
			if (text.contains("London") && text.contains("Montreal") && text.contains("B3")) {
				targetElement = elem;
			}
		}
		if (targetElement == null) {
			fail("Target Bus London Montreal B3 not found");
		}
		WebElement viewButton = driver.findElement(By.xpath("/html/body/table/tbody/tr[3]/td[9]/a"));
		String dftWindow = driver.getWindowHandle();
		viewButton.click();
		Set<String> wins = driver.getWindowHandles();
		for (String s : wins)
			if (!s.equals(dftWindow)) {
				driver.switchTo().window(s);
				break;
			}
		List<WebElement> elems = driver.findElements(By.className("row_even"));
		elems.addAll( driver.findElements(By.className("row_odd")) );
		String[] need = { "Guy", "Castlegrove" };
		Boolean[] result = { false, false };
		for ( WebElement elem : elems ) {
			for ( int i = 0; i < need.length; ++i ) {
				if ( elem.getText().contains(need[i]) ) {
					result[i] = true;
					break;
				}
			}
		}
		for ( int i = 0; i < need.length; ++i ) {
			if ( !result[i] ) {
				fail ( "Cound't find " + need[i] + " in page." );
			}
		}
		driver.switchTo().window(dftWindow);
	}

	@Test
	public void canViewPickUpPointsOfR3() {
		openApplicationAndLogin();
		verifyRoutesAreVisible();
		verifyPickupPoints();
	}

	@After
	public void cleanup() {
		driver.quit();
	}
}