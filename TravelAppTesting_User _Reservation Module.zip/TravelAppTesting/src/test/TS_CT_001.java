package test;

import static org.junit.jupiter.api.Assertions.fail;

import java.io.File;
import java.io.FileWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class TS_CT_001 {
	private WebDriver driver;
	private final String applink = "http://localhost:8080/TravelApp/";
	private final String user_id = "capstone";
	private final String user_password = "info6068";
	private final String target_String = "Welcome to EasyJourney: Online bus reservation.";
	private final String frameButtons = "leftTop", frameContent = "tgt";
	private final String testButtonName = "Cancel Tickets";

	@Before
	public void create() {
		this.driver = new ChromeDriver();

	}

	/*
	 * public void waitByXpath(String xpath) { WebDriverWait wait = new
	 * WebDriverWait(driver, Duration.ofSeconds(10));
	 * wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpath))); }
	 */

	public void clickByCss(String css) {
		driver.findElement(By.cssSelector(css)).click();
	}

	public void clickByXpath(String xpath) {
		driver.findElement(By.xpath(xpath)).click();
	}

	public void sendKeyByCss(String css, String key) {
		driver.findElement(By.cssSelector(css)).sendKeys(key);
	}

	public String getSourceFrame(String frameName, int currentDepth) {
		try {
			for (int i = 0; i < currentDepth; ++i)
				driver.switchTo().parentFrame();
			driver.switchTo().frame(frameName);
			return driver.getPageSource();
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
			ex.printStackTrace();
		}
		fail("Could not find frame to get source test");
		return frameName;
	}

	public void clickButtonByNameFrame(String frameName, String xpath, String name) {
		try {
			driver.switchTo().parentFrame();
			driver.switchTo().frame(frameName);
			List<WebElement> elements = driver.findElements(By.xpath(xpath));
			for (WebElement element : elements) {
				if (element.getText().equals(name)) {
					element.click();
					break;
				}
			}
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
			ex.printStackTrace();
		}
	}

	List<WebElement> getElementsByClassInFrame(String frameName, String className) {
		List<WebElement> elements = null;
		try {
			driver.switchTo().parentFrame();
			driver.switchTo().frame(frameName);
			elements = driver.findElements(By.className(className));
			return elements;
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
			ex.printStackTrace();
		}
		fail("Something bad happended while getting elements");
		return elements;
	}

	List<WebElement> getElementsByClass(String className) {
		List<WebElement> elements = null;
		try {
			elements = driver.findElements(By.className(className));
			return elements;
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
			ex.printStackTrace();
		}
		fail("Something bad happended while getting elements");
		return elements;
	}

	public void openApplicationAndLogin() {
		driver.get(applink);
		clickByCss("Button[class='loginButton']");
		sendKeyByCss("input[name='Name']", user_id);
		sendKeyByCss("input[name='Pwd']", user_password);
		clickByCss("input[value='Submit']");
		String text = getSourceFrame("tgt", 0);
		Assert.assertTrue(text.contains(target_String));
	}

	public void pushTicketIdIntoFile(String ticketID) {
		try {
			String fileName = "TicketIDs.txt";
			File fl = new File(fileName);
			if (!fl.exists())
				fl.createNewFile();
			ticketID += "\n";
			Files.write(Paths.get(fileName), ticketID.getBytes(), StandardOpenOption.APPEND);
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
			ex.printStackTrace();
			fail("Couldn't save itcket id into file ");
		}
	}

	public String popTicketIdFromFile() {
		try {
			String fileName = "TicketIDs.txt";
			File ticketId = new File(fileName);
			Scanner sc = new Scanner(ticketId);
			List<String> all = new ArrayList<>();
			String retId = "";
			Boolean found = false;
			while (sc.hasNextLine()) {
				if (!found) {
					retId = sc.nextLine();
					found = true;
				} else {
					all.add(sc.nextLine());
				}
			}
			sc.close();
			if (!found)
				fail("No ticked it in queue to delete");
			FileWriter myWriter = new FileWriter(fileName);
			for (String st : all) {
				myWriter.append(st + "\n");
			}
			myWriter.close();
			return retId;
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
			ex.printStackTrace();
			fail("Queue file failed");
		}
		return "";
	}

	public void verifyTicketFoundWinId() {
		clickButtonByNameFrame(frameButtons, "//button[@type='button']", testButtonName);
		driver.switchTo().parentFrame();
		driver.switchTo().frame(frameContent);
		WebElement ticketId = driver.findElement(By.name("TicketId"));
		String tckId = popTicketIdFromFile();
		pushTicketIdIntoFile(tckId);
		ticketId.sendKeys(tckId);
		WebElement cancelBtn = driver.findElement(By.xpath("//input[@value='Cancel Ticket']"));
		cancelBtn.click();
		String source = getSourceFrame(frameContent, 1);
		String targets[] = { "R3", "London", "Montreal", "2024-01-31", "21:00:00", "09:00:00", "Guy", "600" };
		for (String target : targets) {
			if (!source.contains(target)) {
				fail("Valid ticket not found");
			}
		}
		// System.out.println(source);
	}

	@Test
	public void canFindTicketWithValidTID() {
		openApplicationAndLogin();
		verifyTicketFoundWinId();
	}

	@After
	public void cleanup() {
		driver.quit();
	}
}
