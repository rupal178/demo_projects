import static org.junit.jupiter.api.Assertions.*;

import java.util.Set;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

class ViewTravels {
	static WebDriver driver;
	
//	@BeforeAll
//	static void setUpBeforeClass() throws Exception {
//		System.setProperty("webdriver.chrome.driver","./chromedriver.exe");
//		
//		driver = new ChromeDriver();
//		driver.manage().window().maximize();
//		driver.get("http://localhost:8080/TravelApp/");
//		//driver.get("http://localhost:8080/TravelApp/User.html");
//		driver.findElement(By.xpath("//button[contains(.,'Admin Login')]")).click();
//		driver.findElement(By.xpath("//input[@name='Name']")).sendKeys("admin");
//		driver.findElement(By.xpath("//input[@name='Pwd']")).sendKeys("admin");
//		driver.findElement(By.xpath("//input[@value='Submit']")).click();
//		//driver.findElement(By.xpath("//img[@name='AddTravel']")).click();
//
//	}
	
	@BeforeEach
	void setUp() throws Exception {
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://localhost:8080/TravelApp/");
		//driver.get("http://localhost:8080/TravelApp/User.html");
		driver.findElement(By.xpath("//button[contains(.,'Admin Login')]")).click();
		driver.findElement(By.xpath("//input[@name='Name']")).sendKeys("admin");
		driver.findElement(By.xpath("//input[@name='Pwd']")).sendKeys("admin");
		driver.findElement(By.xpath("//input[@value='Submit']")).click();
		//driver.findElement(By.xpath("//img[@name='AddTravel']")).click();

		driver.switchTo().defaultContent();
		driver.switchTo().frame(0);
		driver.findElement(By.name("ViewTravels")).click();
		driver.switchTo().defaultContent();
		driver.switchTo().frame(1);
	}
	
	@Test
	void testViewTravelPage() {
		assertEquals("View Travels", driver.findElement(By.xpath("//font[contains(.,'View Travels')]")).getText());
	}
	
	@Test
	void testAddBusDetailsWithValidInfo() throws InterruptedException {
		driver.findElement(By.xpath("//a[contains(.,'Add')]")).click();
		Alert alert = driver.switchTo().alert();
		alert.accept();
		Thread.sleep(5000);
//		Set<String> handler = driver.getWindowHandles();
//		Iterator<String> it = handler.iterator();
//		String parentWindowId = it.next();
//		System.out.println("parent window id" + parentWindowId);
//		String subwindow = it.next();
//		System.out.println("sub window id" + subwindow);
//		driver.switchTo().window(subwindow);
//		System.out.println(driver.getCurrentUrl());
//		String parentWindowHandler = driver.getWindowHandle();
//		String subWindowHandler = null;
//		Set<String> handles = driver.getWindowHandles();
//		Iterator<String> iterator = handles.iterator();
//		while (iterator.hasNext()) {
//			subWindowHandler = iterator.next();
//		}
//		driver.switchTo().window(subWindowHandler);
		Set<String> windowHandles = driver.getWindowHandles();
		String[] handlesArray = windowHandles.toArray(new String[0]);
		String popupWindowHandle = handlesArray[1];
		driver.switchTo().window(popupWindowHandle);
		WebElement dropdownElement = driver.findElement(By.xpath("//select[@name='BusType']"));
		Select dropdown = new Select(dropdownElement);
		dropdown.selectByVisibleText("AC");
		driver.findElement(By.xpath("//input[@name='BusNumber']")).sendKeys("1");
		driver.findElement(By.xpath("//input[@value='Submit']")).click();
		assertEquals("Bus added Successfully", driver.findElement(By.xpath("//font[contains(.,'Bus added Successfully')]")).getText());
	}

	@Test
	void testAddBusDetailsWithEmptyBusType() throws InterruptedException {
		driver.findElement(By.xpath("//a[contains(.,'Add')]")).click();
		Alert alert = driver.switchTo().alert();
		alert.accept();
		Thread.sleep(5000);
		Set<String> windowHandles = driver.getWindowHandles();
		String[] handlesArray = windowHandles.toArray(new String[0]);
		String popupWindowHandle = handlesArray[1];
		driver.switchTo().window(popupWindowHandle);
//		WebElement dropdownElement = driver.findElement(By.xpath("//select[@name='BusType']"));
//		Select dropdown = new Select(dropdownElement);
//		dropdown.selectByVisibleText("AC");
		driver.findElement(By.xpath("//input[@name='BusNumber']")).sendKeys("1");
		driver.findElement(By.xpath("//input[@value='Submit']")).click();
		Alert alert1 = driver.switchTo().alert();
		
		assertEquals("BusType is mandatory", alert1.getText());
	}
	
	@Test
	void testAddBusDetailsWithEmptyBusNumber() throws InterruptedException {
		driver.findElement(By.xpath("//a[contains(.,'Add')]")).click();
		Alert alert = driver.switchTo().alert();
		alert.accept();
		Thread.sleep(5000);
		Set<String> windowHandles = driver.getWindowHandles();
		String[] handlesArray = windowHandles.toArray(new String[0]);
		String popupWindowHandle = handlesArray[1];
		driver.switchTo().window(popupWindowHandle);
		WebElement dropdownElement = driver.findElement(By.xpath("//select[@name='BusType']"));
		Select dropdown = new Select(dropdownElement);
		dropdown.selectByVisibleText("AC");
//		driver.findElement(By.xpath("//input[@name='BusNumber']")).sendKeys("1");
		driver.findElement(By.xpath("//input[@value='Submit']")).click();
		Alert alert1 = driver.switchTo().alert();
		
		assertEquals("BusNumber is mandatory", alert1.getText());
	}
	
	@Test
	void testAddBusDetailsWithInvalidBusNumber() throws InterruptedException {
		driver.findElement(By.xpath("//a[contains(.,'Add')]")).click();
		Alert alert = driver.switchTo().alert();
		alert.accept();
		Thread.sleep(5000);
		Set<String> windowHandles = driver.getWindowHandles();
		String[] handlesArray = windowHandles.toArray(new String[0]);
		String popupWindowHandle = handlesArray[1];
		driver.switchTo().window(popupWindowHandle);
		WebElement dropdownElement = driver.findElement(By.xpath("//select[@name='BusType']"));
		Select dropdown = new Select(dropdownElement);
		dropdown.selectByVisibleText("AC");
		driver.findElement(By.xpath("//input[@name='BusNumber']")).sendKeys("?");
		driver.findElement(By.xpath("//input[@value='Submit']")).click();
		Alert alert1 = driver.switchTo().alert();
		
		assertEquals("Please enter valid BusNumber", alert1.getText());
	}
	
	@Test
	void testClearButton() throws InterruptedException {
		driver.findElement(By.xpath("//a[contains(.,'Add')]")).click();
		Alert alert = driver.switchTo().alert();
		alert.accept();
		Thread.sleep(5000);
		Set<String> windowHandles = driver.getWindowHandles();
		String[] handlesArray = windowHandles.toArray(new String[0]);
		String popupWindowHandle = handlesArray[1];
		driver.switchTo().window(popupWindowHandle);
		WebElement dropdownElement = driver.findElement(By.xpath("//select[@name='BusType']"));
		Select dropdown = new Select(dropdownElement);
		dropdown.selectByVisibleText("AC");
		driver.findElement(By.xpath("//input[@name='BusNumber']")).sendKeys("1");
		driver.findElement(By.xpath("//input[@value='Clear']")).click();
		driver.findElement(By.xpath("//input[@value='Submit']")).click();
		Alert alert1 = driver.switchTo().alert();
		
		assertEquals("BusType is mandatory", alert1.getText());
	}
	
	@Test
	void testViewBus() throws InterruptedException {
		driver.findElement(By.xpath("//a[contains(.,'View')]")).click();
		Alert alert = driver.switchTo().alert();
		alert.accept();
		Thread.sleep(5000);
		Set<String> windowHandles = driver.getWindowHandles();
		String[] handlesArray = windowHandles.toArray(new String[0]);
		String popupWindowHandle = handlesArray[1];
		driver.switchTo().window(popupWindowHandle);
		assertEquals("View Buses", driver.findElement(By.xpath("//font[contains(.,'View Buses')]")).getText());
	}
}
