import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

class AddTravel {
	static WebDriver driver;
	
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		System.setProperty("webdriver.chrome.driver","./chromedriver.exe");
		
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://localhost:8080/TravelApp/");
		//driver.get("http://localhost:8080/TravelApp/User.html");
		driver.findElement(By.xpath("//button[contains(.,'Admin Login')]")).click();
		driver.findElement(By.xpath("//input[@name='Name']")).sendKeys("admin");
		driver.findElement(By.xpath("//input[@name='Pwd']")).sendKeys("admin");
		driver.findElement(By.xpath("//input[@value='Submit']")).click();
		//driver.findElement(By.xpath("//img[@name='AddTravel']")).click();

	}
	
	@BeforeEach
	void setUp() throws Exception {
		driver.switchTo().defaultContent();
		driver.switchTo().frame(0);
		driver.findElement(By.name("AddTravel")).click();
		driver.switchTo().defaultContent();
		driver.switchTo().frame(1);
	}

	@AfterEach
	void tearDown() throws Exception {
		
	}

	@Test
	void testAddTravelPage() {
//		driver.switchTo().frame(0);
//		driver.findElement(By.name("AddTravel")).click();
//		driver.switchTo().defaultContent();
//		driver.switchTo().frame(1);
//		WebElement dropdownElement = driver.findElement(By.xpath("//select[@name='RouteId']"));
//		Select dropdown = new Select(dropdownElement);
//		dropdown.selectByVisibleText("R9");
//		driver.findElement(By.xpath("//input[@value='Delete']")).click();
//		Actions actions = new Actions(driver);
//		actions.sendKeys(Keys.RETURN).perform();
		assertEquals("Add New Travel", driver.findElement(By.xpath("//font[contains(.,'Add New Travel')]")).getText());
	}
	
	@Test
	void testAddTravelWithValidInfo() {
		driver.findElement(By.xpath("//input[@name='Travels']")).sendKeys("Name");
		WebElement dropdownElement = driver.findElement(By.xpath("//select[@name='Location']"));
		Select dropdown = new Select(dropdownElement);
		dropdown.selectByVisibleText("Ambaji");
		driver.findElement(By.xpath("//textarea[@name='Address']")).sendKeys("London Street");
		driver.findElement(By.xpath("//input[@name='AgentName']")).sendKeys("Bob");
		driver.findElement(By.xpath("//input[@name='PhoneNumber']")).sendKeys("1234567890");
		driver.findElement(By.xpath("//input[@value='Submit']")).click();
		driver.switchTo().defaultContent();
		driver.switchTo().frame(1);
		assertEquals("Travels added Successfully", driver.findElement(By.xpath("//font[contains(@face,'Georgia')]")).getText());
	}
	
	@Test
	void testAddTravelWithEmptyTravelsName() {
		//driver.findElement(By.xpath("//input[@name='Travels']")).sendKeys("Name");
		WebElement dropdownElement = driver.findElement(By.xpath("//select[@name='Location']"));
		Select dropdown = new Select(dropdownElement);
		dropdown.selectByVisibleText("Ambaji");
		driver.findElement(By.xpath("//textarea[@name='Address']")).sendKeys("London Street");
		driver.findElement(By.xpath("//input[@name='AgentName']")).sendKeys("Bob");
		driver.findElement(By.xpath("//input[@name='PhoneNumber']")).sendKeys("1234567890");
		driver.findElement(By.xpath("//input[@value='Submit']")).click();
		driver.switchTo().defaultContent();
		driver.switchTo().frame(1);
		assertEquals("Travels Name is mandatory", driver.findElement(By.xpath("//font[contains(@face,'Georgia')]")).getText());
	}
	
	@Test
	void testAddTravelWithInvalidTravelsName() {
		driver.findElement(By.xpath("//input[@name='Travels']")).sendKeys("?");
		WebElement dropdownElement = driver.findElement(By.xpath("//select[@name='Location']"));
		Select dropdown = new Select(dropdownElement);
		dropdown.selectByVisibleText("Ambaji");
		driver.findElement(By.xpath("//textarea[@name='Address']")).sendKeys("London Street");
		driver.findElement(By.xpath("//input[@name='AgentName']")).sendKeys("Bob");
		driver.findElement(By.xpath("//input[@name='PhoneNumber']")).sendKeys("1234567890");
		driver.findElement(By.xpath("//input[@value='Submit']")).click();
		driver.switchTo().defaultContent();
		driver.switchTo().frame(1);
		assertEquals("Please enter valid Travels Name", driver.findElement(By.xpath("//font[contains(@face,'Georgia')]")).getText());
	}
	
	@Test
	void testAddTravelWithEmptyAddress() {
		driver.findElement(By.xpath("//input[@name='Travels']")).sendKeys("Name");
		WebElement dropdownElement = driver.findElement(By.xpath("//select[@name='Location']"));
		Select dropdown = new Select(dropdownElement);
		dropdown.selectByVisibleText("Ambaji");
		//driver.findElement(By.xpath("//textarea[@name='Address']")).sendKeys("London Street");
		driver.findElement(By.xpath("//input[@name='AgentName']")).sendKeys("Bob");
		driver.findElement(By.xpath("//input[@name='PhoneNumber']")).sendKeys("1234567890");
		driver.findElement(By.xpath("//input[@value='Submit']")).click();
		driver.switchTo().defaultContent();
		driver.switchTo().frame(1);
		assertEquals("Address is mandatory", driver.findElement(By.xpath("//font[contains(@face,'Georgia')]")).getText());
	}
	
	@Test
	void testAddTravelWithInvalidAddress() {
		driver.findElement(By.xpath("//input[@name='Travels']")).sendKeys("Name");
		WebElement dropdownElement = driver.findElement(By.xpath("//select[@name='Location']"));
		Select dropdown = new Select(dropdownElement);
		dropdown.selectByVisibleText("Ambaji");
		driver.findElement(By.xpath("//textarea[@name='Address']")).sendKeys("?");
		driver.findElement(By.xpath("//input[@name='AgentName']")).sendKeys("Bob");
		driver.findElement(By.xpath("//input[@name='PhoneNumber']")).sendKeys("1234567890");
		driver.findElement(By.xpath("//input[@value='Submit']")).click();
		driver.switchTo().defaultContent();
		driver.switchTo().frame(1);
		assertEquals("Please enter valid Address", driver.findElement(By.xpath("//font[contains(@face,'Georgia')]")).getText());
	}
	
	@Test
	void testAddTravelWithEmptyAgentName() {
		driver.findElement(By.xpath("//input[@name='Travels']")).sendKeys("Name");
		WebElement dropdownElement = driver.findElement(By.xpath("//select[@name='Location']"));
		Select dropdown = new Select(dropdownElement);
		dropdown.selectByVisibleText("Ambaji");
		driver.findElement(By.xpath("//textarea[@name='Address']")).sendKeys("London Street");
		//driver.findElement(By.xpath("//input[@name='AgentName']")).sendKeys("Bob");
		driver.findElement(By.xpath("//input[@name='PhoneNumber']")).sendKeys("1234567890");
		driver.findElement(By.xpath("//input[@value='Submit']")).click();
		driver.switchTo().defaultContent();
		driver.switchTo().frame(1);
		assertEquals("Agent Name is mandatory", driver.findElement(By.xpath("//font[contains(@face,'Georgia')]")).getText());
	}
	
	@Test
	void testAddTravelWithInvalidAgentName() {
		driver.findElement(By.xpath("//input[@name='Travels']")).sendKeys("Name");
		WebElement dropdownElement = driver.findElement(By.xpath("//select[@name='Location']"));
		Select dropdown = new Select(dropdownElement);
		dropdown.selectByVisibleText("Ambaji");
		driver.findElement(By.xpath("//textarea[@name='Address']")).sendKeys("London Street");
		driver.findElement(By.xpath("//input[@name='AgentName']")).sendKeys("?");
		driver.findElement(By.xpath("//input[@name='PhoneNumber']")).sendKeys("1234567890");
		driver.findElement(By.xpath("//input[@value='Submit']")).click();
		driver.switchTo().defaultContent();
		driver.switchTo().frame(1);
		assertEquals("Please enter valid Agent Name", driver.findElement(By.xpath("//font[contains(@face,'Georgia')]")).getText());
	}
	
	@Test
	void testAddTravelWithEmptyPhoneNumber() {
		driver.findElement(By.xpath("//input[@name='Travels']")).sendKeys("Name");
		WebElement dropdownElement = driver.findElement(By.xpath("//select[@name='Location']"));
		Select dropdown = new Select(dropdownElement);
		dropdown.selectByVisibleText("Ambaji");
		driver.findElement(By.xpath("//textarea[@name='Address']")).sendKeys("London Street");
		driver.findElement(By.xpath("//input[@name='AgentName']")).sendKeys("Bob");
		//driver.findElement(By.xpath("//input[@name='PhoneNumber']")).sendKeys("1234567890");
		driver.findElement(By.xpath("//input[@value='Submit']")).click();
		driver.switchTo().defaultContent();
		driver.switchTo().frame(1);
		assertEquals("Phone Number is mandatory", driver.findElement(By.xpath("//font[contains(@face,'Georgia')]")).getText());
	}
	
	@Test
	void testAddTravelWithInvalidPhoneNumber() {
		driver.findElement(By.xpath("//input[@name='Travels']")).sendKeys("Name");
		WebElement dropdownElement = driver.findElement(By.xpath("//select[@name='Location']"));
		Select dropdown = new Select(dropdownElement);
		dropdown.selectByVisibleText("Ambaji");
		driver.findElement(By.xpath("//textarea[@name='Address']")).sendKeys("London Street");
		driver.findElement(By.xpath("//input[@name='AgentName']")).sendKeys("Bob");
		driver.findElement(By.xpath("//input[@name='PhoneNumber']")).sendKeys("?");
		driver.findElement(By.xpath("//input[@value='Submit']")).click();
		driver.switchTo().defaultContent();
		driver.switchTo().frame(1);
		assertEquals("Please enter valid Phone Number", driver.findElement(By.xpath("//font[contains(@face,'Georgia')]")).getText());
	}
	
	@Test
	void testClearButton() {
		driver.findElement(By.xpath("//input[@name='Travels']")).sendKeys("Name");
		WebElement dropdownElement = driver.findElement(By.xpath("//select[@name='Location']"));
		Select dropdown = new Select(dropdownElement);
		dropdown.selectByVisibleText("Ambaji");
		driver.findElement(By.xpath("//textarea[@name='Address']")).sendKeys("London Street");
		driver.findElement(By.xpath("//input[@name='AgentName']")).sendKeys("Bob");
		driver.findElement(By.xpath("//input[@name='PhoneNumber']")).sendKeys("1234567890");
		driver.findElement(By.xpath("//input[@value='Clear']")).click();
		driver.findElement(By.xpath("//input[@value='Submit']")).click();
		driver.switchTo().defaultContent();
		driver.switchTo().frame(1);
		assertEquals("Please enter valid Travel information", driver.findElement(By.xpath("//font[contains(@face,'Georgia')]")).getText());
	}
}
