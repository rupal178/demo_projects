import static org.junit.jupiter.api.Assertions.*;

import java.util.Set;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

class DeleteTravel {
	static WebDriver driver;
	
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		System.setProperty("webdriver.chrome.driver","./chromedriver.exe");
		
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://localhost:8080/TravelApp/");
		//driver.get("http://localhost:8080/TravelApp/User.html");
		driver.findElement(By.xpath("//button[contains(.,'Admin Login')]")).click();
		driver.findElement(By.xpath("//input[@name='Name']")).sendKeys("admin");
		driver.findElement(By.xpath("//input[@name='Pwd']")).sendKeys("admin");
		driver.findElement(By.xpath("//input[@value='Submit']")).click();
		//driver.findElement(By.xpath("//img[@name='AddTravel']")).click();

	}
	
	@BeforeEach
	void setUp() throws Exception {
		driver.switchTo().defaultContent();
		driver.switchTo().frame(0);
		driver.findElement(By.name("DelTravel")).click();
		driver.switchTo().defaultContent();
		driver.switchTo().frame(1);
	}

	@Test
	void testDeleteTravelPage() {
		assertEquals("Delete Travel", driver.findElement(By.xpath("//font[contains(.,'Delete Travel ')]")).getText());
	}

	@Test
	void testViewTravelDetailsWithValidSelection() throws InterruptedException {
		WebElement dropdownElement = driver.findElement(By.xpath("//select[@name='TravelsId']"));
		Select dropdown = new Select(dropdownElement);
		dropdown.selectByVisibleText("T2");
		driver.findElement(By.xpath("//input[@value='ShowDetails']")).click();
		Thread.sleep(5000);
		Set<String> windowHandles = driver.getWindowHandles();
		String[] handlesArray = windowHandles.toArray(new String[0]);
		String popupWindowHandle = handlesArray[1];
		driver.switchTo().window(popupWindowHandle);
		assertEquals("Travels Details", driver.findElement(By.xpath("//h2[contains(.,'Travels Details')]")).getText());
	}
	
	@Test
	void testViewTravelDetailsWithInvalidSelection() throws InterruptedException {
//		WebElement dropdownElement = driver.findElement(By.xpath("//select[@name='TravelsId']"));
//		Select dropdown = new Select(dropdownElement);
//		dropdown.selectByVisibleText("T2");
		driver.findElement(By.xpath("//input[@value='ShowDetails']")).click();
		Thread.sleep(5000);
		Alert alert = driver.switchTo().alert();
		assertEquals("Please select TravelsId to Proceed", alert.getText());

	}
	
	@Test
	void testDeleteTravelWithValidSelection() throws InterruptedException {
		WebElement dropdownElement = driver.findElement(By.xpath("//select[@name='TravelsId']"));
		Select dropdown = new Select(dropdownElement);
		dropdown.selectByVisibleText("T6");
		driver.findElement(By.xpath("//input[@value='Delete']")).click();
		Thread.sleep(5000);
		Alert alert = driver.switchTo().alert();
		alert.accept();
		driver.switchTo().defaultContent();
		assertEquals("Travel deleted successfully", driver.findElement(By.xpath("h2")).getText());
	}
	
	@Test
	void testDeleteTravelWithInvalidSelection() throws InterruptedException {
//		WebElement dropdownElement = driver.findElement(By.xpath("//select[@name='TravelsId']"));
//		Select dropdown = new Select(dropdownElement);
//		dropdown.selectByVisibleText("T6");
		driver.findElement(By.xpath("//input[@value='Delete']")).click();
		Thread.sleep(5000);
		Alert alert = driver.switchTo().alert();
		alert.accept();
		Thread.sleep(5000);
		Alert alert1 = driver.switchTo().alert();
		assertEquals("Please select TravelsId to Proceed", alert1.getText());
	}
}
