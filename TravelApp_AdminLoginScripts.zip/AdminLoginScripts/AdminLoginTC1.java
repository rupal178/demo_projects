package CapstoneProject1;
/*
 *  Validate travel app login page load succesfully.
 */

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class AdminLoginTC1 {
	
	WebDriver driver;
	
	@Test(priority=1)
	 void openBrowser() 
	 {
	
		 
		WebDriverManager.firefoxdriver().setup();
		driver=new FirefoxDriver();
		
	    driver.get("http://localhost:8080/TravelApp/");
	    driver.manage().window().maximize();
		 
		//edge browser
		//WebDriverManager.edgedriver().setup();
		//WebDriver driver=new EdgeDriver();
		 
		//open brwoser
		//	WebDriverManager.chromedriver().setup();
		//	WebDriver driver=new ChromeDriver();
		 
		 
	 }
	@Test(priority=2)
	void closeBrowser()
	{
		driver.close();
	}
	
}
