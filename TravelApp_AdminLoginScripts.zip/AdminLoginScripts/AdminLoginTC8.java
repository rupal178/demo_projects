package CapstoneProject1;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class AdminLoginTC8 {

WebDriver driver;
	
	@Test(priority=1)
	 void openBrowser() 
	 {
		 
		WebDriverManager.firefoxdriver().setup();
		 driver=new FirefoxDriver();
		
		
	 }
	@Test(priority=2)
	void openURL()
	{
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.get("http://localhost:8080/TravelApp/");
		driver.manage().window().maximize();
	}
	
	@Test(priority=3)
	void Login()
	{
		driver.findElement(By.cssSelector("button[onclick='openAdminLoginPage()']")).click();
		driver.findElement(By.name("Name")).sendKeys("");
		driver.findElement(By.name("Pwd")).sendKeys("");
		driver.findElement(By.cssSelector("input[value='Submit']")).click();
		System.out.println(driver.findElement(By.xpath("//font[@color='Red']")).getText());
		
	}

	

}
